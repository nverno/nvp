package PlSense::ModuleBuilder;

use strict;
use warnings;
use Class::Std;
{
    sub build {
        my ($self, $mdl) = @_;
    }
}

1;

__END__

