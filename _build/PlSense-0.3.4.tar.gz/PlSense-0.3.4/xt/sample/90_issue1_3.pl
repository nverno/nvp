#!/usr/bin/perl

use vars qw( $foo %hogege );

# astart use vars by qw has multiple 1
#$
# aend include: foo hogege

# astart use vars by qw has multiple 2
#%
# aend include: hogege

