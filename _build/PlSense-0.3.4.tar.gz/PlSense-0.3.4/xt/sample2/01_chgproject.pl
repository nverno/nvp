#!/usr/bin/perl

use File::Copy;

# astart project module in other project
#&File::Copy::
# aend equal: File::Copy::other_copy

