package File::Copy;

use strict;
use warnings;

sub other_copy {
    return "";
}

1;

