#!/usr/bin/perl

use File::Copy;

# astart installed module in local project
#&File::Copy::
# aend include: File::Copy::copy

